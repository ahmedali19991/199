<h2 align="centre">⸢ 𝘾𝙍 • 𝙎𝙊𝙐𝙍𝘾𝙀 ⸥.</h2>

<p align="center">
  <img src="https://telegra.ph/file/1a38e52936d7007199c78.jpg">
</p>

<h3>⸢ 𝘾𝙍 • 𝙎𝙊𝙐𝙍𝘾𝙀 ⸥</h3>

- جميع الحقوق محفوظه لدي سورس كريستين

- chat etalee [𝘾𝙍 • 𝙎𝙊𝙐𝙍𝘾𝙀](https://t.me/cr_source) (𝘾𝙍 v1)
- Python (3.10+)

### اوامر التشغيل 🛠
#### في كل المجموعات 
- `/play` - reply to youtube url or song file to play song
- `شغل` - لتشغيل الاغاني في المحدثه الصوتيه
- `/vplay` - reply to youtube url or song file to play song
- `تشغيل فيديو` - لتشغيل فيديو في المحدثه الصوتية 
- `ايقاف` - للايقاف الاغني
- `وقف` - للايقاف الفيديو

#### الاومر الاخري
- `/pause` - pause song play
- `/resume` - resume song play
- `كمل` - لاستمرار الاغنيه
- `/skip` - play next song
- `تخطي` - لتخطي الاغنيه
- `/end` - stop music play
- `ايقاف` - لايقاف الاغنيه نهائي 
- `تحميل` - لتحميل الاغنيه فيديو او صوت علي حسب اختيارك mp4 or mp3


## تنصيب علي هروكو 💜

يمكنك الان التنصيب علي هروكو الحد الاقصي لوجود الاكوانت هروكو هو 20 يوم فقط

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/etmusicbot/etmusicbot)


## 🖇 VPS Deployment

> Checkout [Docs](https://notreallyshikhar.gitbook.io/yukkimusicbot/deployment/local-hosting-or-vps) for Detailed Explanation on VPS Deploy


```console
shikhar@MacBook~ $ git clone الجيت الخاصه بتنصيب
shikhar@MacBook~ $ cd الجيت
shikhar@MacBook~ $ sudo bash setup
```
> Setup will install each and every requirement, nodejs and pip packages automatically. After successfull installation of requirements , setup will ask you to input your vars.
> Please input your vars correctly.

```console
shikhar@MacBook~ $ bash start
```

> Not Getting VPS Method? [Watch Tutorial](https://t.me/cr_source)


<img src="https://telegra.ph/file/1a38e52936d7007199c78.jpg" align="center">



## 𝑫𝑬𝑽𝑬𝑳𝑶𝑷𝑬𝑹 

## ⸢ 𝘾𝙍 • 𝙎𝙊𝙐𝙍𝘾𝙀 ⸥

## Support Updates 

<a href="https://t.me/SORS0Coo"><img src="https://img.shields.io/badge/Join-Group%20Support-red.svg?style=for-the-badge&logo=Telegram"></a> <a href="https://t.me/cr_source"><img src="https://img.shields.io/badge/Join-Updates%20Channel-white.svg?style=for-the-badge&logo=Telegram"></a>
